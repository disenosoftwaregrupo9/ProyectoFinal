/*
Date:18/01/2020
Purpose: Proyecto Base de Datos Veterinario Dr.Pelos
*/
DROP DATABASE IF EXISTS veterinaria;

CREATE DATABASE veterinaria;

use veterinaria;

DROP TABLE IF EXISTS repartidor;

CREATE TABLE repartidor (
    ci_repartidor     		VARCHAR(10)        				NOT NULL,  
    nombres   	 	        VARCHAR(20)    					NOT NULL,
    primerApellido 	        VARCHAR(20)    					NOT NULL,
    segundoApellido 	    VARCHAR(20)  					NOT NULL,
    fecha_nacimiento  	 	DATE            				NOT NULL,
    email			   	    VARCHAR(40)     				NOT NULL,	
	genero    				ENUM ('M','F')  				NOT NULL,
    estadoCivil				ENUM ('Soltero','Casado','Divorciado','Union Libre', 'Viudo')  NOT NULL,
    direccionResidencia	    VARCHAR(60)     				NOT NULL,
    edad		       		INT             				NOT NULL, 
	telefonoMovil1   	    VARCHAR(10)     				NOT NULL,
    telefonoMovil2   	    VARCHAR(10),
    telefonofijo   	    	VARCHAR(10),
    nacionalidad			VARCHAR(20)     				NOT NULL,
    PRIMARY KEY (ci_repartidor),  
    UNIQUE  KEY (ci_repartidor)                 
);


DROP TABLE IF EXISTS jefeBodega;

CREATE TABLE jefeBodega (
    ci_jefeBodega     		VARCHAR(10)        				NOT NULL,  
    nombres   	 	        VARCHAR(20)    					NOT NULL,
    primerApellido 	        VARCHAR(20)    					NOT NULL,
    segundoApellido 	    VARCHAR(20)  					NOT NULL,
    fecha_nacimiento  	 	DATE            				NOT NULL,
    email			   	    VARCHAR(40)     				NOT NULL,	
	genero    				ENUM ('M','F')  				NOT NULL,
    estadoCivil				ENUM ('Soltero','Casado','Divorciado','Union Libre', 'Viudo')  NOT NULL,
    direccionResidencia	    VARCHAR(60)     				NOT NULL,
    edad		       		INT             				NOT NULL, 
	telefonoMovil1   	    VARCHAR(10)     				NOT NULL,
    telefonoMovil2   	    VARCHAR(10),
    telefonofijo   	    	VARCHAR(10),
    nacionalidad			VARCHAR(20)     				NOT NULL,
    ci_repartidor			VARCHAR(7)     				NOT NULL,
    FOREIGN KEY (ci_repartidor) REFERENCES repartidor (ci_repartidor),
    PRIMARY KEY (ci_jefeBodega),  
    UNIQUE  KEY (ci_jefeBodega)                 
);

DROP TABLE IF EXISTS envio;

CREATE TABLE envio (
	id_envio 				INT			       				NOT NULL  AUTO_INCREMENT, 
    fechaEnvio		  	 	DATE            				NOT NULL,
    horaEnvio		  	 	TIME            				NOT NULL,
    sectorEnvio			    VARCHAR(25)						NOT NULL,
    direccionEnvio			VARCHAR(60)                     NOT NULL,
	ci_repartidor     		char(10)        				NOT NULL,  
    FOREIGN KEY (ci_repartidor) REFERENCES repartidor (ci_repartidor),
    PRIMARY KEY (id_envio)
);


DROP TABLE IF EXISTS pago;

CREATE TABLE pago (
	codigo_pago			char(10)						NOT NULL,
    tipoPago		        VARCHAR(60)                     NOT NULL,
	total	     	float            				NOT NULL,
    PRIMARY KEY (codigo_pago)
);

DROP TABLE IF EXISTS producto;

CREATE TABLE producto (
	codigo_producto			char(10)						NOT NULL,
    descripcion		        VARCHAR(60)                     NOT NULL,
	precioUnitario	     	float            				NOT NULL,
    PRIMARY KEY (codigo_producto)
);


DROP TABLE IF EXISTS mascota;

CREATE TABLE mascota (
	codigo_mascota  		char(10)						NOT NULL,
    nombre  		        VARCHAR(30)                     NOT NULL,
	raza        	     	VARCHAR(30)                     NOT NULL,
    tipo                    VARCHAR(30)                     NOT NULL,
    PRIMARY KEY (codigo_mascota)
);

DROP TABLE IF EXISTS servicio;

CREATE TABLE servicio (
	codigo_servicio			char(10)						NOT NULL,
    descripcion		        VARCHAR(60)                     NOT NULL,
	precioUnitario	     	float            				NOT NULL,
    codigo_mascota  		char(10)						NOT NULL,
    FOREIGN KEY (codigo_mascota) REFERENCES mascota (codigo_mascota),
    PRIMARY KEY (codigo_servicio)
);

DROP TABLE IF EXISTS cajero;

CREATE TABLE cajero (
    ci_cajero       		char(10)        				NOT NULL,  
    nombres   	 	        VARCHAR(20)    					NOT NULL,
    primerApellido 	        VARCHAR(20)    					NOT NULL,
    segundoApellido 	    VARCHAR(20)  					NOT NULL,
    fecha_nacimiento  	 	DATE            				NOT NULL,
    email			   	    VARCHAR(40)     				NOT NULL,	
	genero    				ENUM ('M','F')  				NOT NULL,
    estadoCivil				ENUM ('Soltero','Casado','Divorciado','Union Libre', 'Viudo')  NOT NULL,
    direccionResidencia	    VARCHAR(60)     				NOT NULL,
    sectorResidencia	    VARCHAR(20)     				NOT NULL,
    edad		       		INT             				NOT NULL, 
	telefonoMovil1   	    VARCHAR(10)     				NOT NULL,
    telefonoMovil2   	    VARCHAR(10),
    telefonofijo   	    	VARCHAR(10)     				NOT NULL,
    nacionalidad			VARCHAR(20)     				NOT NULL,
	tipoEmpleado			VARCHAR(20)     				NOT NULL,
    PRIMARY KEY (ci_cajero),   
    UNIQUE  KEY (ci_cajero)   
);


DROP TABLE IF EXISTS cliente;

CREATE TABLE cliente (
    id_cliente       		char(10)        				NOT NULL, 
    nombres   	 	        VARCHAR(20)    					NOT NULL,
    primerApellido 	        VARCHAR(20)    					NOT NULL,
    segundoApellido 	    VARCHAR(20)  					NOT NULL,
    telefonoMovil1   	    VARCHAR(10)     				NOT NULL,
    telefonoMovil2   	    VARCHAR(10),
    email			   	    VARCHAR(60),	
    direccion			    VARCHAR(60),
	telefonoFijo		    VARCHAR(10),
    genero    				ENUM ('M','F')  				NOT NULL,
    ciudadResidencia	    VARCHAR(20),
    paisResidencia		    VARCHAR(20),
    edad		       		INT, 
    PRIMARY KEY (id_cliente),   
    UNIQUE  KEY (id_cliente)                   
);

DROP TABLE IF EXISTS directivo;

CREATE TABLE directivo (
	ci_directivo		    char(13)        				NOT NULL,  
    nombres   	 	        VARCHAR(20)    					NOT NULL,
    primerApellido 	        VARCHAR(20)    					NOT NULL,
    segundoApellido 	    VARCHAR(20)  					NOT NULL,
    telefonoMovil1   	    VARCHAR(10)     				NOT NULL,
    telefonoMovil2   	    VARCHAR(10),
    email			   	    VARCHAR(60),	
    direccion			    VARCHAR(60),
	telefonoFijo		    VARCHAR(10),
    genero    				ENUM ('M','F')  				NOT NULL,
    ciudadResidencia	    VARCHAR(20),
    paisResidencia		    VARCHAR(20),
    edad		       		INT, 
    PRIMARY KEY (ci_directivo),   
    UNIQUE  KEY (ci_directivo)        
);

DROP TABLE IF EXISTS agencia;

CREATE TABLE agencia (
	ruc_agencia		   		char(13)        				NOT NULL,  
    nombreAgencia			VARCHAR(30)     				NOT NULL,
	direccionAgencia  		VARCHAR(60)        				NOT NULL,  
    telefono1   		    VARCHAR(10)     				NOT NULL,
    telefono2   		    VARCHAR(10),
    localidad	   	    	VARCHAR(20)     				NOT NULL,
    PRIMARY KEY (ruc_agencia)
);


DROP TABLE IF EXISTS pedido;

CREATE TABLE pedido (
	no_pedido 				char(10) 						NOT NULL,
	ruc_agencia				char(13) 						NOT NULL,
    fechaPedido		  	 	DATE            				NOT NULL,
    horaPedido		  	 	TIME            				NOT NULL,
    total			     	float            				DEFAULT 0,
    subtotal		     	float            				DEFAULT 0,
    iva 			     	float            				DEFAULT 0,
    ci_cajero       		char(10)        				NOT NULL,  
    id_cliente       		char(10)        				NOT NULL,  
    codigo_pago			    char(10)						NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES cliente (id_cliente),
    FOREIGN KEY (codigo_pago) REFERENCES pago (codigo_pago),
    FOREIGN KEY (ci_cajero) REFERENCES cajero (ci_cajero),
    FOREIGN KEY (ruc_agencia) REFERENCES agencia (ruc_agencia),
    PRIMARY KEY (no_pedido)
);


DROP TABLE IF EXISTS detalle;

CREATE TABLE detalle (
	id_detalle 		    	INT								NOT NULL AUTO_INCREMENT,
    no_item 				INT								NOT NULL,
    cantidadArticulos		INT             				NOT NULL, 
	codigo_producto    		char(10)        			    NOT NULL, 
    codigo_servicio    		char(10)        			    NOT NULL, 
    id_envio    			int        						NOT NULL, 
    precioNeto		  	 	float            				NOT NULL,
    descuentoNeto		  	float							DEFAULT 0,
	no_pedido 				char(10) 						NOT NULL,
    FOREIGN KEY (no_pedido) REFERENCES pedido (no_pedido),
    FOREIGN KEY (codigo_producto) REFERENCES producto (codigo_producto) ,
    FOREIGN KEY (codigo_servicio) REFERENCES servicio (codigo_servicio) ,
    FOREIGN KEY (id_envio) REFERENCES envio (id_envio),
    PRIMARY KEY (id_detalle)
);

            

INSERT INTO repartidor (ci_repartidor , nombres, primerApellido , segundoApellido , fecha_nacimiento,
				email , genero ,  estadoCivil, direccionResidencia, edad , telefonoMovil1, 
				telefonoMovil2, telefonofijo ,  nacionalidad) VALUES 
	('0985321859','Juan Carlos','Mera','Mera', DATE '1994-12-05','juanm1996@hotmail.com','M','Soltero', 'Coop. Santiaguito de Roldos Mz 47 Solar 836', 25,'0985046222',Null, '2960129' ,'Ecuatoriana');
   
   
INSERT INTO envio (id_envio , fechaEnvio, horaEnvio , sectorEnvio , 
				direccionEnvio, ci_repartidor) VALUES 
	(1,   '2020-01-22' , TIME '12:30:00', 'Sauces' , 'Sauces 9 Mz 345 Solar 15' , '0985321859' );
            

    
INSERT INTO cajero (ci_cajero , nombres, primerApellido , segundoApellido , 
				fecha_nacimiento, email, genero, estadoCivil, direccionResidencia, 
                sectorResidencia, edad,  telefonoMovil1 , telefonoMovil2, telefonofijo,
                nacionalidad,tipoEmpleado ) VALUES 
	('0952519684', 'Michael Edison' , 'Mendieta' , 'Suarez','1996-02-10', 'lcdo98@hotmail.com', 'F', 'Soltero', 'Fertisa Mz354 Solar 23','Florida Norte', 23, '0985867233',Null,'2678443','Ecuatoriana','Vendedor'),
	('0967890098', 'Lisbeth Margaret' , 'Ruiz' , 'Castro','1997-02-28', 'lisbethruiz97@hotmail.com', 'F', 'Soltero', 'Coop. Patria Nueva Mz354 Solar 23','Florida Norte', 22, '0985867233',Null,'2678443','Ecuatoriana','Vendedor');


INSERT INTO cliente (id_cliente , nombres, primerApellido , segundoApellido , 
				telefonoMovil1 , telefonoMovil2 , email, direccion, 
                telefonofijo, genero, ciudadResidencia , paisResidencia ) VALUES 
	('0967890098', 'Luisa' , 'Perez' , 'Mendieta', '3219042877', '0956258974','adrianamonbebe@hotmail.com', 'Sauces 6 Mz 34 Solar 147', '2598631', 'F', 'Medellin', 'Colombia'),
    ('0959684520', 'Maria luisa' , 'Temepaguay' , 'Gonzalez', '1614690395', Null ,'jessica18@hotmail.com', 'Coop. Pancho Jacome Mz34 Solar 4', '2598631', 'F', 'New York', 'USA'),
    ('0984571201', 'Fernanda' , 'Pozo' , 'Reyes', '0942568955', '0956258974','ferrey@hotmail.com', 'Samanes 4 Mz 24 Solar 3', '2598631', 'F', 'Guayaquil', 'Ecuador'),
    ('0952316548', 'Miguel' , 'Muñoz' , 'Armando', '0942568955', '0956258974','munozarma@hotmail.com', 'Sauces 6 Mz 34 Solar 147', '2598631', 'M', 'Guayaquil', 'Ecuador'),
    ('0984751265', 'Gonzalo' , 'Asuncion' , 'Peñafiel', '0952687451', '0958745621','gonzaas@hotmail.com', 'Sauces 6 Mz 34 Solar 147', '2598631', 'M', 'Guayaquil', 'Ecuador');

 
INSERT INTO directivo (ci_directivo , nombres, primerApellido , segundoApellido , 
				telefonoMovil1 , telefonoMovil2 , email, direccion, 
                telefonofijo, genero, ciudadResidencia , paisResidencia ) VALUES 
	('0967890098', 'Luisa' , 'Perez' , 'Mendieta', '3219042877', '0956258974','adrianamonbebe@hotmail.com', 'Sauces 6 Mz 34 Solar 147', '2598631', 'F', 'Medellin', 'Colombia'),
    ('0959684520', 'Maria luisa' , 'Temepaguay' , 'Gonzalez', '1614690395', Null ,'jessica18@hotmail.com', 'Coop. Pancho Jacome Mz34 Solar 4', '2598631', 'F', 'New York', 'USA'); 
    
    
 INSERT INTO agencia (ruc_agencia , nombreAgencia, direccionAgencia , telefono1 , 
				telefono2, localidad) VALUES 
	('1360074400001',  'Eternity Guayaquil' , 'Florida Norte Coop. Pancho Jacome Mz 13 Solar 354' , '098559865', '0983867216', 'Guayaquil');
   
    
INSERT INTO producto (codigo_producto , descripcion, precioUnitario) VALUES 
	(1,  'amoxicilina' , 30.00 ),
    (2,  'vestido rosado' , 60.00 ),
    (3,  'Dog chow' , 12.00 ),
    (4,  'Cat chow' , 8.00 );
    

INSERT INTO mascota (codigo_mascota , nombre, raza, tipo) VALUES 
	(1,  'casy' , 'chihuahua' , 'perro' ),
    (2,  'luli' , 'french' , 'perro'),
    (3,  'calec' , 'pitbull' , 'perro'),
    (4,  'kira' , 'siames' , 'gato');

INSERT INTO servicio (codigo_servicio , descripcion, precioUnitario, codigo_mascota) VALUES 
	(1,  'corte de pelo' , 30.00 , 1 ),
    (2,  'consulta media' , 60.00 , 2),
    (3,  'baño de espuma' , 12.00 , 1),
    (4,  'desparacitacion' , 8.00 , 1);

INSERT INTO pago (codigo_pago , tipoPago, total) VALUES 
	(1,  'efectivo' , 30.00 ),
    (2,  'tarjeta' , 60.00 ),
    (3,  'efectivo' , 12.00),
    (4,  'tarjeta' , 8.00 );
   
INSERT INTO pedido (no_pedido , ruc_agencia, fechaPedido , horaPedido , 
				total, subtotal , iva , ci_cajero , id_cliente, codigo_pago) VALUES 
	('1',  '1360074400001' , '2019-01-18' , '12:30:00', 60, 52.80 , 7.20 , '0952519684', '0967890098',1 ),
    ('2',  '1360074400001' , '2019-01-19' , '12:30:00', 60, 60.00 , 8.30 , '0952519684', '0959684520' ,2),
    ('3',  '1360074400001' , '2019-01-18' , '11:30:00', 60, 48.00 , 6.20 , '0967890098', '0984751265',3);  
    
INSERT INTO detalle (id_detalle , no_item, cantidadArticulos , codigo_producto, codigo_servicio , 
				id_envio, precioNeto, descuentoNeto,  no_pedido) VALUES 
	(1,  1 , 2 , 2, 1, 1, 60.00, Null, 1);
    
    
/*PROCEDURE PARA PODER HACER EL REGISTRO DE CLIENTES*/
DROP PROCEDURE IF EXISTS REGISTRAR_CLIENTE;
DELIMITER $
CREATE PROCEDURE REGISTRAR_CLIENTE(IN id1 char(10),IN nombre1 varchar(16),IN apellido11 varchar(16), 
apellido12 varchar(16),IN telf1 varchar(10), IN telf2 varchar(10),IN  email1 VARCHAR(16),IN direccion1 VARCHAR(25),
IN telefonoFijo1 VARCHAR(10),IN genero1 ENUM ('M','F'),IN ciudad1 VARCHAR(20),IN pais1 VARCHAR(10),
IN edad1 INT )
	BEGIN
		IF NOT EXISTS (SELECT id_cliente, nombres, primerApellido,segundoApellido ,telefonoMovil1,telefonoMovil2,
        email,direccion,telefonoFijo,genero,ciudadResidencia,paisResidencia,edad FROM cliente
        WHERE id_cliente = id1) THEN
			INSERT INTO cliente( id_cliente, nombres, primerApellido,segundoApellido ,telefonoMovil1,telefonoMovil2,
        email,direccion,telefonoFijo,genero,ciudadResidencia,paisResidencia,edad) 
        VALUES (id1,nombre1,apellido11,apellido12,telf1,telf2,email1,direccion1,telefonoFijo1,genero1,ciudad1,pais1,
        edad1);
		END IF;
	END$
DELIMITER ;


/*PROCEDURE PARA PODER MODIFICAR LOS CLIENTES*/
DROP PROCEDURE IF EXISTS MODIFICAR_CLIENTE;
DELIMITER $
CREATE PROCEDURE MODIFICAR_CLIENTE(IN id1 char(10),IN nombre1 varchar(16),IN apellido11 varchar(16), 
apellido12 varchar(16),IN telf1 varchar(10), IN telf2 varchar(10),IN  email1 VARCHAR(16),IN direccion1 VARCHAR(25),
IN fijo1 VARCHAR(10),IN genero1 ENUM ('M','F'),IN ciudad1 VARCHAR(20),IN pais1 VARCHAR(10),
IN edad1 INT)
	BEGIN
		UPDATE cliente SET id_cliente = id1, nombres = nombre1, primerApellido = apellido11,segundoApellido = apellido12 ,
        telefonoMovil1 = telf1 ,telefonoMovil2 = telf2, email = email1 ,direccion = direccion1,telefonoFijo = fijo1,
        genero = genero1 ,ciudadResidencia = ciudad1,paisResidencia = pais1 ,edad = edad1;
	END$
DELIMITER ;

/*PRECUDRE PARA ELIMINAR AL CLIENTE */
DROP PROCEDURE IF EXISTS ELIMINAR_CLIENTE;
DELIMITER $
CREATE PROCEDURE ELIMINAR_CLIENTE(IN id1 VARCHAR(10))
	BEGIN
		DELETE FROM cliente WHERE id_cliente = id1;
		DELETE FROM pedido WHERE id_cliente = id1;
	END$
DELIMITER ;

/*PROCUDRE PARA BUSCAR UN CLIENTE */
DROP PROCEDURE IF EXISTS BUSCAR_CLIENTE;
DELIMITER $
CREATE PROCEDURE BUSCAR_CLIENTE(IN id1 VARCHAR(10))
	BEGIN
		SELECT id_cliente, nombres, primerApellido,segundoApellido ,telefonoMovil1,telefonoMovil2,
        email,direccion,telefonoFijo,genero,ciudadResidencia,paisResidencia,edad FROM cliente
        WHERE id_cliente = id1;
	END$
DELIMITER ;


/*PROCEDURE PARA BUSCAR UN PEDIDO*/
DROP PROCEDURE IF EXISTS BUSCAR_PEDIDO;
DELIMITER $
CREATE PROCEDURE BUSCAR_PEDIDO(IN ped1 CHAR(10))
	BEGIN
		SELECT no_pedido , no_agencia, fechaPedido, horaPedido, total, subtotal, iva , id_detalle , ci_cajero
        id_cliente FROM pedido WHERE no_pedido = ped1;
	END$
DELIMITER ;

/*VISTA PARA LAS GANANCIAS MENSUALES*/
DROP VIEW IF EXISTS GananciasMensuales;
CREATE VIEW GananciasMensuales(Mes, VentasdelMes) AS
	SELECT MONTH(fechaPedido) AS mes, SUM(total) AS totalVendido
	FROM pedido
	GROUP BY MONTH(fechaPedido);
    
/* Compra hecha por un cliente*/
DROP VIEW IF EXISTS reporteVentas;
CREATE VIEW reporteVentas(NombreCliente, Apellido,idPedido, precioCompra) AS
	SELECT c.nombres, c.primerApellido, p.no_pedido ,p.total
	FROM Cliente c JOIN Pedido p ON c.id_cliente = p.id_cliente;


/*PROCEDURE PARA ELIMINAR UN PEDIDO*/
DROP PROCEDURE IF EXISTS ELIMINAR_PEDIDO;
DELIMITER |
CREATE PROCEDURE ELIMINAR_PEDIDO(IN n_pedido char(10))
BEGIN
DELETE FROM Pedido where no_pedido=n_pedido;
END |
DELIMITER ;

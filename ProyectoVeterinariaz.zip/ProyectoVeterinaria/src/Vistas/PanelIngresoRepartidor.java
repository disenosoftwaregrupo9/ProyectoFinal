package Vistas;


import Clases.Repartidor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PanelIngresoRepartidor extends javax.swing.JFrame {
    
    public PanelIngresoRepartidor() {
        initComponents();
        Show_Repartidor_In_JTable();
        this.setTitle("REGISTRO REPARTIDOR");
        this.setLocation(500, 500);
        
        
    }

    
    public Connection getConnection()
   {
       Connection con;
       try {
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/eternity?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root","1234");
           System.out.println("Se ha establecido una conexión a la base de datos " +  
                                       "\n " ); 
           return con;
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
   }
    
    
    
 // get a list of users from mysql database
   public ArrayList<Repartidor> getLista()
   {
       ArrayList<Repartidor> Lista = new ArrayList<Repartidor>();
       Connection connection = getConnection();
       
       String query = "SELECT * FROM  repartidor ";
       Statement st;
       ResultSet rs;
       
       try {
           st = connection.createStatement();
           rs = st.executeQuery(query);
           Repartidor repartidor;
           while(rs.next())
           {
               repartidor = new Repartidor(rs.getString("ci_repartidor"),rs.getString("nombres"),rs.getString("primerApellido"), rs.getString("segundoApellido"), rs.getString("fecha_nacimiento"), rs.getString("email"), rs.getString("genero"), rs.getString("estadoCivil"), rs.getString("direccionResidencia"), rs.getString("edad"), rs.getString("telefonoMovil1"), rs.getString("telefonoMovil2"), rs.getInt("telefonofijo"), rs.getString("nacionalidad"));
               Lista.add(repartidor);
           }
       } catch (Exception e) {
           e.printStackTrace();
       }
       return Lista;
   }
   
   // Display Data In JTable
   
   public void Show_Repartidor_In_JTable()
   {
       ArrayList<Repartidor> list = getLista();
       DefaultTableModel model = (DefaultTableModel)jTable_Display.getModel();
       Object[] row = new Object[15];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getCi_repartidor();
           row[1] = list.get(i).getNombres();
           row[2] = list.get(i).getPrimerApellido();
           row[3] = list.get(i).getSegundoApellido();
           row[4] = list.get(i).getFechaNacimiento();
           row[5] = list.get(i).getEmail();
           row[6] = list.get(i).getGenero();
           row[7] = list.get(i).getEstadoCivil();
           row[8] = list.get(i).getDireccionResidencia();
           row[9] = list.get(i).getEdad();
           row[10] = list.get(i).getTelefono1();
           row[11] = list.get(i).getTelefono2();
           row[12] = list.get(i).getTelefonoFijo();
           row[13] = list.get(i).getNacionalidad();
           model.addRow(row);
       }
    }
   
   // Execute The Insert Update And Delete Querys
   public void executeSQlQuery(String query, String message)
   {
       Connection con = getConnection();
       Statement st;
       try{
           st = con.createStatement();
           if((st.executeUpdate(query)) == 1)
           {
               // refresh jtable data
               DefaultTableModel model = (DefaultTableModel)jTable_Display.getModel();
               model.setRowCount(0);
               Show_Repartidor_In_JTable();
               
               JOptionPane.showMessageDialog(null, "Data "+message+" Succefully");
           }else{
               JOptionPane.showMessageDialog(null, "Data Not "+message);
           }
       }catch(Exception ex){
           ex.printStackTrace();
       }
   }
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bntVolver = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_cedula = new javax.swing.JTextField();
        txt_nombre = new javax.swing.JTextField();
        txt_Apellido1 = new javax.swing.JTextField();
        txt_Apellido2 = new javax.swing.JTextField();
        txt_fecha = new javax.swing.JTextField();
        txt_email = new javax.swing.JTextField();
        txt_genero = new javax.swing.JTextField();
        txt_nacionalidad = new javax.swing.JTextField();
        txt_estadocivil = new javax.swing.JTextField();
        txt_direccion = new javax.swing.JTextField();
        txt_placa = new javax.swing.JTextField();
        txt_edad = new javax.swing.JTextField();
        txt_telefono1 = new javax.swing.JTextField();
        txt_telefono2 = new javax.swing.JTextField();
        txt_telefonofijo = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jButton_Insert = new javax.swing.JButton();
        jButton_Update = new javax.swing.JButton();
        jButton_Delete = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_Display = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bntVolver.setText("Volver");
        bntVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntVolverActionPerformed(evt);
            }
        });
        getContentPane().add(bntVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 420, 90, -1));

        jLabel1.setText("Cedula");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 63, -1, -1));

        jLabel2.setText("Nombre");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel3.setText("Primer Apellido");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        jLabel4.setText("Segundo Apellido");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        jLabel14.setText("Fecha Nacimiento");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, -1));

        jLabel15.setText("Email");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, -1));

        jLabel16.setText("Género");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, -1, -1));

        jLabel5.setText("Nacionalidad");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, -1, -1));
        getContentPane().add(txt_cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 70, -1));
        getContentPane().add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, 70, -1));

        txt_Apellido1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_Apellido1ActionPerformed(evt);
            }
        });
        getContentPane().add(txt_Apellido1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 120, 70, -1));
        getContentPane().add(txt_Apellido2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, 70, -1));

        txt_fecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_fechaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 70, -1));
        getContentPane().add(txt_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, 70, -1));
        getContentPane().add(txt_genero, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 240, 70, -1));
        getContentPane().add(txt_nacionalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 270, 70, -1));
        getContentPane().add(txt_estadocivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(351, 63, 60, -1));
        getContentPane().add(txt_direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 90, 60, -1));
        getContentPane().add(txt_placa, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 120, 60, -1));
        getContentPane().add(txt_edad, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 150, 60, -1));
        getContentPane().add(txt_telefono1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 180, 60, -1));
        getContentPane().add(txt_telefono2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 210, 60, -1));
        getContentPane().add(txt_telefonofijo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 240, 60, -1));

        jLabel23.setText("Telefono Fijo");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 240, -1, -1));

        jLabel22.setText("Telefono Movil 2");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 210, -1, -1));

        jLabel21.setText("Telefono Movil 1");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 180, -1, -1));

        jLabel20.setText("Edad");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 150, -1, -1));

        jLabel19.setText("Placa");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, -1, -1));

        jLabel18.setText("Dirección");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, -1, -1));

        jLabel17.setText("Estado Civil");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, -1, -1));

        jButton_Insert.setText("Ingresar");
        jButton_Insert.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add.png"))); // NOI18N
        jButton_Insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_InsertActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Insert, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 350, 90, -1));

        jButton_Update.setText("Actualizar");
        jButton_Update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/refresh.png"))); // NOI18N
        jButton_Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, 90, -1));

        jButton_Delete.setText("Eliminar");
        jButton_Delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete.png"))); // NOI18N
        jButton_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_DeleteActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 350, 90, -1));

        jTable_Display.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Cedula", "Nombres", "Primer Apellido", "Segundo Apellido", "Fecha Nacimiento", "Email", "Genero", "Estado Civil", "Direccionl", "Edad", "Telefono 1", "Telefono 2", "Telefono fijo", "Nacionalidad", "No.Placa"
            }
        ));
        jTable_Display.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_DisplayMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable_Display);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 40, 860, 100));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntVolverActionPerformed
        // TODO add your handling code here:
        PanelPrincipal p= new PanelPrincipal();
        
        p.setVisible(true);
        p.setLocationRelativeTo(null);
        this.dispose();
        
    }//GEN-LAST:event_bntVolverActionPerformed

    private void txt_Apellido1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_Apellido1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_Apellido1ActionPerformed

    private void txt_fechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_fechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_fechaActionPerformed

    
    
    private void jButton_InsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_InsertActionPerformed
       
       
        
        
        String c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14;
        c0=txt_cedula.getText();
        c1=txt_nombre.getText();
        c2=txt_Apellido1.getText();
        c3=txt_Apellido2.getText();
        c4=txt_fecha.getText();
        c5=txt_email.getText();
        c6=txt_genero.getText();
        c7=txt_estadocivil.getText();
        c8=txt_direccion.getText();
        c9=txt_edad.getText();
        c10=txt_telefono1.getText();
        c11=txt_telefono2.getText();
        c12=txt_telefonofijo.getText();
        c13=txt_nacionalidad.getText();
        
        
        
        String query ="INSERT INTO repartidor VALUES('" + c0+ "','" + c1 + "','"+c2+"','"+c3+"','"+c4+"','"+c5+"','"+c6+"','"+c7+"','"+c8+"','"+c9+"','"+c10+"','"+c11+"','"+c12+"','"+c13+"')";

        executeSQlQuery(query, "Inserted");
        
        
        
    }//GEN-LAST:event_jButton_InsertActionPerformed

    private void jButton_UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_UpdateActionPerformed
        String query = "UPDATE 'repartidor' SET 'nombres'='"+txt_nombre.getText()+"','primerApellido'="+txt_Apellido1.getText()+"','segundoApellido'="+txt_Apellido2.getText()+"','fechaNacimiento'="+txt_fecha.getText()+"','email'="+txt_email.getText()+"','genero'="+txt_genero.getText()+"','estadoCivil'="+txt_estadocivil.getText()+"','direccionResidencia'="+txt_direccion.getText()+"','telefono1'="+txt_telefono1.getText()+"','telefono2'="+txt_telefono2.getText()+"','telefonoFijo'="+txt_telefonofijo.getText()+"','edad'="+txt_edad.getText()+"','nacionalidad'="+txt_nacionalidad.getText()+" WHERE 'ci_repartidor' = "+txt_cedula.getText();
        executeSQlQuery(query, "Updated");
    }//GEN-LAST:event_jButton_UpdateActionPerformed

    private void jButton_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_DeleteActionPerformed
        String query = "DELETE FROM repartidor WHERE ci_repartidor = "+txt_cedula.getText();
        executeSQlQuery(query, "Deleted");
        
    }//GEN-LAST:event_jButton_DeleteActionPerformed

    private void jTable_DisplayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_DisplayMouseClicked
        // Get The Index Of The Slected Row
        int i = jTable_Display.getSelectedRow();

        TableModel model = jTable_Display.getModel();

        // Display Slected Row In JTexteFields
        txt_cedula.setText(model.getValueAt(i,0).toString());
        
        txt_nombre.setText(model.getValueAt(i,1).toString());

        txt_Apellido1.setText(model.getValueAt(i,2).toString());

        txt_Apellido2.setText(model.getValueAt(i,3).toString());

        txt_fecha.setText(model.getValueAt(i,4).toString());
        
        txt_email.setText(model.getValueAt(i,5).toString());

        txt_genero.setText(model.getValueAt(i,6).toString());
        
        txt_estadocivil.setText(model.getValueAt(i,7).toString());

        txt_direccion.setText(model.getValueAt(i,8).toString());
        
        txt_telefono1.setText(model.getValueAt(i,9).toString());
        
        txt_telefono2.setText(model.getValueAt(i,10).toString());
        
        txt_telefonofijo.setText(model.getValueAt(i,11).toString());
        
        txt_edad.setText(model.getValueAt(i,12).toString());
        
        txt_nacionalidad.setText(model.getValueAt(i,13).toString());
    }//GEN-LAST:event_jTable_DisplayMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoRepartidor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoRepartidor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoRepartidor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoRepartidor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PanelIngresoRepartidor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bntVolver;
    private javax.swing.JButton jButton_Delete;
    private javax.swing.JButton jButton_Insert;
    private javax.swing.JButton jButton_Update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable_Display;
    private javax.swing.JTextField txt_Apellido1;
    private javax.swing.JTextField txt_Apellido2;
    private javax.swing.JTextField txt_cedula;
    private javax.swing.JTextField txt_direccion;
    private javax.swing.JTextField txt_edad;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_estadocivil;
    private javax.swing.JTextField txt_fecha;
    private javax.swing.JTextField txt_genero;
    private javax.swing.JTextField txt_nacionalidad;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_placa;
    private javax.swing.JTextField txt_telefono1;
    private javax.swing.JTextField txt_telefono2;
    private javax.swing.JTextField txt_telefonofijo;
    // End of variables declaration//GEN-END:variables
}

package Vistas;


import Clases.Mascota;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PanelIngresoMascota extends javax.swing.JFrame {

    public PanelIngresoMascota() {
        initComponents();
        Show_In_JTable();
        this.setTitle("REGISTRO ");
        this.setLocation(500, 500);
    }
    public int id_autoincrement()
    {
        int id =1;
        PreparedStatement ps =null; 
        ResultSet rs = null; 
        try {
            ps = getConnection().prepareStatement("SELECT MAX(codigo_mascota) FROM destinatario;");
            rs = ps.executeQuery();
            
            while(rs.next())
           {
               id = rs.getInt(1)+1;
           }
        } catch (SQLException ex) {
            Logger.getLogger(PanelIngresoMascota.class.getName()).log(Level.SEVERE, null, ex);
        }finally {
            try {
                ps.close();
                rs.close();
            }catch(Exception ex) {
                
            }
        }
        return id;
    }
    public Connection getConnection()
   {
       Connection con;
       try {
           
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/eternity?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root","1234");
          
           System.out.println("Se ha establecido una conexión a la base de datos " +  
                                       "\n " ); 
           return con;
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
   }
   public ArrayList<Mascota> getVehiculoList()
   {
       ArrayList<Mascota> mascotasList = new ArrayList<Mascota>();
       Connection connection = getConnection();
       
       String query = "SELECT * FROM  mascota ";
       Statement st;
       ResultSet rs;
       
       try {
           st = connection.createStatement();
           rs = st.executeQuery(query);
           Mascota mascota;
           while(rs.next())
           {
               mascota = new Mascota(rs.getInt("codigo_mascota"),rs.getString("nombre"), rs.getString("raza") ,rs.getString("tipo"));
               mascotasList.add(mascota);
           }
       } catch (Exception e) {
           e.printStackTrace();
       }
       return mascotasList;
   }
   
   // Display Data In JTable
   
   public void Show_In_JTable()
   {
       ArrayList<Mascota> list = getVehiculoList();
       DefaultTableModel model = (DefaultTableModel)jTable_Display.getModel();
       Object[] row = new Object[8];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getCodigo_mascota();
           row[1] = list.get(i).getNombres();
           row[2] = list.get(i).getRaza();
           row[3] = list.get(i).getTipo();
           model.addRow(row);
       }
    }
   
   // Execute The Insert Update And Delete Querys
   public void executeSQlQuery(String query, String message)
   {
       Connection con = getConnection();
       Statement st;
       try{
           st = con.createStatement();
           if((st.executeUpdate(query)) == 1)
           {
               // refresh jtable data
               DefaultTableModel model = (DefaultTableModel)jTable_Display.getModel();
               model.setRowCount(0);
               Show_In_JTable();
               
               JOptionPane.showMessageDialog(null, "Data "+message+" Succefully");
           }else{
               JOptionPane.showMessageDialog(null, "Data Not "+message);
           }
       }catch(Exception ex){
           ex.printStackTrace();
       }
   }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnVolver = new javax.swing.JButton();
        jTextField_nombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField_raza = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField_tipo = new javax.swing.JTextField();
        jTextField_insert = new javax.swing.JButton();
        jTextField_delete = new javax.swing.JButton();
        jTextField_update = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_Display = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        getContentPane().add(btnVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 440, -1, -1));

        jTextField_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_nombreActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 190, 70, -1));

        jLabel1.setText("Nombre");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, -1, -1));

        jLabel2.setText("Primer Apellido");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, -1, -1));
        getContentPane().add(jTextField_raza, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 70, 20));

        jLabel3.setText("Segundo Apellido");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, -1, -1));
        getContentPane().add(jTextField_tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, 70, -1));

        jTextField_insert.setText("insert");
        jTextField_insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_insertActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_insert, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, -1, -1));

        jTextField_delete.setText("delete");
        jTextField_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_deleteActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 370, -1, -1));

        jTextField_update.setText("update");
        jTextField_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_updateActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 370, -1, -1));

        jTable_Display.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "id_destinatario", "nombres", "Primer Apellido ", "Segundo Apellido ", "telefono 1", "telefono2", "genero", "edad"
            }
        ));
        jTable_Display.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_DisplayMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable_Display);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 20, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // TODO add your handling code here:
        PanelPrincipal p= new PanelPrincipal();
        
        p.setVisible(true);
        p.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void jTextField_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_nombreActionPerformed

    private void jTextField_insertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_insertActionPerformed
        
       
         String c0,c1,c2;
         c0=jTextField_nombre.getText();
         c1=jTextField_raza.getText();
         c2=jTextField_tipo.getText();
         
        int id = id_autoincrement();
                 
      String query ="INSERT INTO mascota VALUES('"+ String.valueOf(id)+"','" + c0+ "','" + c1 + "','"+c2+"','"+"')";
        executeSQlQuery(query, "Inserted");
        
        
    }//GEN-LAST:event_jTextField_insertActionPerformed

    private void jTextField_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_updateActionPerformed
       int id = id_autoincrement();
       String query = "UPDATE 'mascota' SET 'nombre'='"+jTextField_nombre.getText()+"','raza'="+jTextField_raza.getText()+"','tipo'="+jTextField_tipo.getText()+ " WHERE 'codigo_mascota' = "+ String.valueOf(id) ;
       executeSQlQuery(query, "Updated");
    }//GEN-LAST:event_jTextField_updateActionPerformed

    private void jTextField_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_deleteActionPerformed
        int id = id_autoincrement();
        String query = "DELETE FROM mascota WHERE codigo_mascota = "+String.valueOf(id);
        executeSQlQuery(query, "Deleted");
    }//GEN-LAST:event_jTextField_deleteActionPerformed

    private void jTable_DisplayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_DisplayMouseClicked
        // Get The Index Of The Slected Row
        int i = jTable_Display.getSelectedRow();

        TableModel model = jTable_Display.getModel();
        
        jTextField_insert = new javax.swing.JButton();
        jTextField_delete = new javax.swing.JButton();
        jTextField_update = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_Display = new javax.swing.JTable();

        // Display Slected Row In JTexteFields
        jTextField_nombre.setText(model.getValueAt(i,0).toString());

        jTextField_raza.setText(model.getValueAt(i,1).toString());

        jTextField_tipo.setText(model.getValueAt(i,2).toString());
    }//GEN-LAST:event_jTable_DisplayMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PanelIngresoMascota().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable_Display;
    private javax.swing.JButton jTextField_delete;
    private javax.swing.JButton jTextField_insert;
    private javax.swing.JTextField jTextField_nombre;
    private javax.swing.JTextField jTextField_raza;
    private javax.swing.JTextField jTextField_tipo;
    private javax.swing.JButton jTextField_update;
    // End of variables declaration//GEN-END:variables
}

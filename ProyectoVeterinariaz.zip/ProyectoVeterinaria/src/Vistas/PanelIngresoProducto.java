package Vistas;


import Clases.Producto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PanelIngresoProducto extends javax.swing.JFrame {
  
    /**
     * Creates new form PanelIngresoRegalo
     */
    public PanelIngresoProducto() {
        initComponents();
        Show_Regalos_In_JTable();
        this.setTitle("VENTANA ");
        this.setLocation(500, 500);
    }
    
    public Connection getConnection()
   {
       Connection con;
       try {
           con = DriverManager.getConnection("jdbc:mysql://localhost:3306/eternity?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root","1234");
           System.out.println("Se ha establecido una conexión a la base de datos " +  
                                       "\n " ); 
           return con;
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
   }
    
   public ArrayList<Producto> getRegaloList()
   {
       ArrayList<Producto> regaloList = new ArrayList<Producto>();
       Connection connection = getConnection();
       
       String query = "SELECT * FROM  producto ";
       Statement st;
       ResultSet rs;
       
       try {
           st = connection.createStatement();
           rs = st.executeQuery(query);
           Producto regalo;
           while(rs.next())
           {
               regalo = new Producto(rs.getInt("codigo_producto"),rs.getString("descripcion"),rs.getInt("precioUnitario"));
               regaloList.add(regalo);
           }
       } catch (Exception e) {
           e.printStackTrace();
       }
       return regaloList;
   }
   
   // Display Data In JTable
   
   public void Show_Regalos_In_JTable()
   {
       ArrayList<Producto> list = getRegaloList();
       DefaultTableModel model = (DefaultTableModel)jTable_Display_Regalo.getModel();
       Object[] row = new Object[4];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getCodigo_regalo();
           row[1] = list.get(i).getDescripcion();
           row[2] = list.get(i).getPrecioUnitario();
           
           model.addRow(row);
       }
    }
   
   // Execute The Insert Update And Delete Querys
   public void executeSQlQuery(String query, String message)
   {
       Connection con = getConnection();
       Statement st;
       try{
           st = con.createStatement();
           if((st.executeUpdate(query)) == 1)
           {
               // refresh jtable data
               DefaultTableModel model = (DefaultTableModel)jTable_Display_Regalo.getModel();
               model.setRowCount(0);
               Show_Regalos_In_JTable();
               
               JOptionPane.showMessageDialog(null, "Data "+message+" Succefully");
           }else{
               JOptionPane.showMessageDialog(null, "Data Not "+message);
           }
       }catch(Exception ex){
           ex.printStackTrace();
       }
   }
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bntVolver = new javax.swing.JButton();
        jTextField_descuento = new javax.swing.JTextField();
        jTextField_precioUnitario = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jTextField_descripcion = new javax.swing.JTextField();
        jTextField_codigo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton_Insert = new javax.swing.JButton();
        jButton_Update = new javax.swing.JButton();
        jButton_Delete = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_Display_Regalo = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bntVolver.setText("Volver");
        bntVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntVolverActionPerformed(evt);
            }
        });
        getContentPane().add(bntVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 330, -1, -1));
        getContentPane().add(jTextField_descuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 70, -1));

        jTextField_precioUnitario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_precioUnitarioActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_precioUnitario, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 70, -1));

        jLabel9.setText("Precio Unitario");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jLabel12.setText("Descuento");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));
        getContentPane().add(jTextField_descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 70, -1));

        jTextField_codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_codigoActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 70, -1));

        jLabel2.setText("Descripcion");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel1.setText("Codigo");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        jButton_Insert.setText("Ingresar");
        jButton_Insert.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/add.png"))); // NOI18N
        jButton_Insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_InsertActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Insert, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        jButton_Update.setText("Actualizar");
        jButton_Update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/refresh.png"))); // NOI18N
        jButton_Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, -1, -1));

        jButton_Delete.setText("Delete");
        jButton_Delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete.png"))); // NOI18N
        jButton_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_DeleteActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, -1, -1));

        jTable_Display_Regalo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable_Display_Regalo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_Display_RegaloMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable_Display_Regalo);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 20, 390, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField_precioUnitarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_precioUnitarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_precioUnitarioActionPerformed

    private void jTextField_codigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_codigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_codigoActionPerformed

    private void bntVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntVolverActionPerformed
        // TODO add your handling code here:
        
        PanelPrincipal p= new PanelPrincipal();
        p.setVisible(true);
        p.setLocationRelativeTo(null);
        this.dispose();
        
        
    }//GEN-LAST:event_bntVolverActionPerformed

    private void jButton_InsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_InsertActionPerformed
       
         String c0,c1,c2,c3;
           
           
           c0=this.jTextField_codigo.getText();
           c1=this.jTextField_descripcion.getText();
           c2=this.jTextField_precioUnitario.getText();
           
           float f1=Float.parseFloat(c2);

            String query="INSERT INTO producto VALUES('" + c0+ "','" + c1 + "','"+f1+"')";
            executeSQlQuery(query, "Inserted");
            
    }//GEN-LAST:event_jButton_InsertActionPerformed

    private void jButton_UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_UpdateActionPerformed
        String query = "UPDATE 'producto' SET 'descripcion'='"+jTextField_descripcion.getText()+"','precioUnitario'="+jTextField_precioUnitario.getText()+" WHERE 'codigo_producto' = "+jTextField_codigo.getText();
        executeSQlQuery(query, "Updated");
    }//GEN-LAST:event_jButton_UpdateActionPerformed

    private void jButton_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_DeleteActionPerformed
        String query = "DELETE FROM producto WHERE codigo_producto = "+jTextField_codigo.getText();
        executeSQlQuery(query, "Deleted");
    }//GEN-LAST:event_jButton_DeleteActionPerformed

    private void jTable_Display_RegaloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_Display_RegaloMouseClicked
        // Get The Index Of The Slected Row
        int i = jTable_Display_Regalo.getSelectedRow();

        TableModel model = jTable_Display_Regalo.getModel();

        // Display Slected Row In JTexteFields
        jTextField_codigo.setText(model.getValueAt(i,0).toString());

        jTextField_descripcion.setText(model.getValueAt(i,1).toString());

        jTextField_precioUnitario.setText(model.getValueAt(i,2).toString());
    }//GEN-LAST:event_jTable_Display_RegaloMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PanelIngresoProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PanelIngresoProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bntVolver;
    private javax.swing.JButton jButton_Delete;
    private javax.swing.JButton jButton_Insert;
    private javax.swing.JButton jButton_Update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable_Display_Regalo;
    private javax.swing.JTextField jTextField_codigo;
    private javax.swing.JTextField jTextField_descripcion;
    private javax.swing.JTextField jTextField_descuento;
    private javax.swing.JTextField jTextField_precioUnitario;
    // End of variables declaration//GEN-END:variables
}

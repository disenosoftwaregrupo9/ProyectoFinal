/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Nicole
 */
public class Pago {
    
    int codigo_servicio; 
    String tipoPago; 
    float total; 

    public Pago(int codigo_servicio, String tipoPago, float total) {
        this.codigo_servicio = codigo_servicio;
        this.tipoPago = tipoPago;
        this.total = total;
    }

    
    public int getCodigo_servicio() {
        return codigo_servicio;
    }

    public void setCodigo_servicio(int codigo_servicio) {
        this.codigo_servicio = codigo_servicio;
    }

    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }
    
    
    
}

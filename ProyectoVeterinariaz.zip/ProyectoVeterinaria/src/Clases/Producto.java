/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Nicole
 */
public class Producto {
    
    int codigo_producto; 
    String descripcion; 
    float precioUnitario;

    public Producto(int codigo_producto, String descripcion, float precioUnitario) {
        this.codigo_producto = codigo_producto;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
    }

    public int getCodigo_regalo() {
        return codigo_producto;
    }

    public void setCodigo_regalo(int codigo_regalo) {
        this.codigo_producto = codigo_regalo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author user
 */
public class Cliente {
    
    
    String id_cliente       	;
    String nombres   	 	 ;       
    String primerApellido 	  ;      
    String segundoApellido 	   ; 
    String telefonoMovil1   	  ;
    String telefonoMovil2   	   ; 
    String email		;	   	 
    String direccion		;	    
	String telefonoFijo	;	    
    String genero    		;		
    String ciudadResidencia	 ;   
    String paisResidencia	;	    
    int edad		       	;	
    
    

    public Cliente(String id_cliente, String nombres, String primerApellido, String segundoApellido, String telefonoMovil1, String telefonoMovil2, String email, String direccion, String telefonoFijo, String genero, String ciudadResidencia, String paisResidencia, int edad) {
        this.id_cliente = id_cliente;
        this.nombres = nombres;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.telefonoMovil1 = telefonoMovil1;
        this.telefonoMovil2 = telefonoMovil2;
        this.email = email;
        this.direccion = direccion;
        this.telefonoFijo = telefonoFijo;
        this.genero = genero;
        this.ciudadResidencia = ciudadResidencia;
        this.paisResidencia = paisResidencia;
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Cliente{" + "id_cliente=" + id_cliente + ", nombres=" + nombres + ", primerApellido=" + primerApellido + ", segundoApellido=" + segundoApellido + ", telefonoMovil1=" + telefonoMovil1 + ", telefonoMovil2=" + telefonoMovil2 + ", email=" + email + ", direccion=" + direccion + ", telefonoFijo=" + telefonoFijo + ", genero=" + genero + ", ciudadResidencia=" + ciudadResidencia + ", paisResidencia=" + paisResidencia + ", edad=" + edad + '}';
    }

    public String getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(String id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public String getTelefonoMovil1() {
        return telefonoMovil1;
    }

    public void setTelefonoMovil1(String telefonoMovil1) {
        this.telefonoMovil1 = telefonoMovil1;
    }

    public String getTelefonoMovil2() {
        return telefonoMovil2;
    }

    public void setTelefonoMovil2(String telefonoMovil2) {
        this.telefonoMovil2 = telefonoMovil2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefonoFijo() {
        return telefonoFijo;
    }

    public void setTelefonoFijo(String telefonoFijo) {
        this.telefonoFijo = telefonoFijo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getCiudadResidencia() {
        return ciudadResidencia;
    }

    public void setCiudadResidencia(String ciudadResidencia) {
        this.ciudadResidencia = ciudadResidencia;
    }

    public String getPaisResidencia() {
        return paisResidencia;
    }

    public void setPaisResidencia(String paisResidencia) {
        this.paisResidencia = paisResidencia;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public void comprarProductos(Producto p) {
     //En construccion
    }
    public void solicitarServicio(Producto p) {
     //En construccion
    }
    
}

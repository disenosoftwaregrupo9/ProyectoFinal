/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Nicole
 */
public class Mascota {
    int codigo_mascota; 
    String nombres; 
    String raza;
    String tipo;

    public Mascota(int codigo_mascota, String nombres, String raza, String tipo) {
        this.codigo_mascota = codigo_mascota;
        this.nombres = nombres;
        this.raza = raza;
        this.tipo = tipo;
    }
    

    public int getCodigo_mascota() {
        return codigo_mascota;
    }

    public void setCodigo_mascota(int codigo_mascota) {
        this.codigo_mascota = codigo_mascota;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}

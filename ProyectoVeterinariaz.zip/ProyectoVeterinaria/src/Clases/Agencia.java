/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author user
 */
public class Agencia {
    
    String ruc_agencia		   	;	  
    String nombreAgencia		;	
String	direccionAgencia  		;
    String telefono1   		    ;
    String telefono2   		    ;
    String localidad	   	    ;	

    public Agencia(String ruc_agencia, String nombreAgencia, String direccionAgencia, String telefono1, String telefono2, String localidad) {
        this.ruc_agencia = ruc_agencia;
        this.nombreAgencia = nombreAgencia;
        this.direccionAgencia = direccionAgencia;
        this.telefono1 = telefono1;
        this.telefono2 = telefono2;
        this.localidad = localidad;
    }

    @Override
    public String toString() {
        return "Agencia{" + "ruc_agencia=" + ruc_agencia + ", nombreAgencia=" + nombreAgencia + ", direccionAgencia=" + direccionAgencia + ", telefono1=" + telefono1 + ", telefono2=" + telefono2 + ", localidad=" + localidad + '}';
    }

    public String getRuc_agencia() {
        return ruc_agencia;
    }

    public void setRuc_agencia(String ruc_agencia) {
        this.ruc_agencia = ruc_agencia;
    }

    public String getNombreAgencia() {
        return nombreAgencia;
    }

    public void setNombreAgencia(String nombreAgencia) {
        this.nombreAgencia = nombreAgencia;
    }

    public String getDireccionAgencia() {
        return direccionAgencia;
    }

    public void setDireccionAgencia(String direccionAgencia) {
        this.direccionAgencia = direccionAgencia;
    }

    public String getTelefono1() {
        return telefono1;
    }

    public void setTelefono1(String telefono1) {
        this.telefono1 = telefono1;
    }

    public String getTelefono2() {
        return telefono2;
    }

    public void setTelefono2(String telefono2) {
        this.telefono2 = telefono2;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }
    
    public void importarProductos(Producto p) {
     
    }
    
    
}

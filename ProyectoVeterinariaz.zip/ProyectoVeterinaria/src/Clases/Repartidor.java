/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Nicole
 */
public class Repartidor {
    String ci_repartidor;
    String nombres;
    String primerApellido;
    String segundoApellido;
    String fechaNacimiento;
    String email;
    String genero;
    String estadoCivil;
    String direccionResidencia;
    String telefono1;
    String telefono2; 
    String telefonoFijo;
    int edad;
    String nacionalidad; 

    public Repartidor(String ci_repartidor, String nombres, String primerApellido, String segundoApellido, String fechaNacimiento, String email, String genero, String estadoCivil, String direccionResidencia, String telefono1, String telefono2, String telefonoFijo, int edad, String nacionalidad) {
        this.ci_repartidor = ci_repartidor;
        this.nombres = nombres;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
        this.genero = genero;
        this.estadoCivil = estadoCivil;
        this.direccionResidencia = direccionResidencia;
        this.telefono1 = telefono1;
        this.telefono2 = telefono2;
        this.telefonoFijo = telefonoFijo;
        this.edad = edad;
        this.nacionalidad = nacionalidad;
    }

    public String getCi_repartidor() {
        return ci_repartidor;
    }

    public void setCi_repartidor(String ci_repartidor) {
        this.ci_repartidor = ci_repartidor;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getDireccionResidencia() {
        return direccionResidencia;
    }

    public void setDireccionResidencia(String direccionResidencia) {
        this.direccionResidencia = direccionResidencia;
    }

    public String getTelefono1() {
        return telefono1;
    }

    public void setTelefono1(String telefono1) {
        this.telefono1 = telefono1;
    }

    public String getTelefono2() {
        return telefono2;
    }

    public void setTelefono2(String telefono2) {
        this.telefono2 = telefono2;
    }

    public String getTelefonoFijo() {
        return telefonoFijo;
    }

    public void setTelefonoFijo(String telefonoFijo) {
        this.telefonoFijo = telefonoFijo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    @Override
    public String toString() {
        return "Repartidor{" + "ci_repartidor=" + ci_repartidor + ", nombres=" + nombres + ", primerApellido=" + primerApellido + ", segundoApellido=" + segundoApellido + ", fechaNacimiento=" + fechaNacimiento + ", email=" + email + ", genero=" + genero + ", estadoCivil=" + estadoCivil + ", direccionResidencia=" + direccionResidencia + ", telefono1=" + telefono1 + ", telefono2=" + telefono2 + ", telefonoFijo=" + telefonoFijo + ", edad=" + edad + ", nacionalidad=" + nacionalidad + '}';
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Nicole
 */
public class Servicio {
    
    int codigo_servicio; 
    String descripcion; 
    float precioUnitario; 
    int codigo_mascota; 

    public Servicio(int codigo_servicio, String descripcion, float precioUnitario, int codigo_mascota) {
        this.codigo_servicio = codigo_servicio;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
        this.codigo_mascota = codigo_mascota;
    }

    public int getCodigo_servicio() {
        return codigo_servicio;
    }

    public void setCodigo_servicio(int codigo_servicio) {
        this.codigo_servicio = codigo_servicio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public int getCodigo_mascota() {
        return codigo_mascota;
    }

    public void setCodigo_mascota(int codigo_mascota) {
        this.codigo_mascota = codigo_mascota;
    }
    
    
    
    
    
}

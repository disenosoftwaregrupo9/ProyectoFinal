/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author user
 */
public class Pedido {
    
    
   String no_pedido 		;		
    String ruc_agencia	;				
    String fechaPedido		 ; 	 	
    String horaPedido		  ;	 	
    float total			   ;  	
    float subtotal		    ; 	
    float iva 			     ;
    String ci_empleado       		;
    String id_cliente       		;
    
    int codigo_pago ;

    public Pedido(String no_pedido, String ruc_agencia, String fechaPedido, String horaPedido, float total, float subtotal, float iva, String ci_empleado, String id_cliente, int codigo_pago) {
        this.no_pedido = no_pedido;
        this.ruc_agencia = ruc_agencia;
        this.fechaPedido = fechaPedido;
        this.horaPedido = horaPedido;
        this.total = total;
        this.subtotal = subtotal;
        this.iva = iva;
        this.ci_empleado = ci_empleado;
        this.id_cliente = id_cliente;
        this.codigo_pago = codigo_pago;
    }

    public String getNo_pedido() {
        return no_pedido;
    }

    public void setNo_pedido(String no_pedido) {
        this.no_pedido = no_pedido;
    }

    public String getRuc_agencia() {
        return ruc_agencia;
    }

    public void setRuc_agencia(String ruc_agencia) {
        this.ruc_agencia = ruc_agencia;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public String getHoraPedido() {
        return horaPedido;
    }

    public void setHoraPedido(String horaPedido) {
        this.horaPedido = horaPedido;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }

    public float getIva() {
        return iva;
    }

    public void setIva(float iva) {
        this.iva = iva;
    }

    public String getCi_empleado() {
        return ci_empleado;
    }

    public void setCi_empleado(String ci_empleado) {
        this.ci_empleado = ci_empleado;
    }

    public String getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(String id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getCodigo_pago() {
        return codigo_pago;
    }

    public void setCodigo_pago(int codigo_pago) {
        this.codigo_pago = codigo_pago;
    }

    
    
    
    
    
    
}

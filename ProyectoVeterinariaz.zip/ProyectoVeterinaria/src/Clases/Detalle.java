/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author user
 */
public class Detalle {
   int id_detalle 		;    									
    int no_item 		;		
    int cantidadArticulos	;	
	String codigo_regalo    ;		
    int id_envio    		;	
    float precioNeto		 ; 	 
    float descuentoNeto		  ;	
    String	no_pedido 	;	

    public Detalle(int id_detalle, int no_item, int cantidadArticulos, String codigo_regalo, int id_envio, float precioNeto, float descuentoNeto, String no_pedido) {
        this.id_detalle = id_detalle;
        this.no_item = no_item;
        this.cantidadArticulos = cantidadArticulos;
        this.codigo_regalo = codigo_regalo;
        this.id_envio = id_envio;
        this.precioNeto = precioNeto;
        this.descuentoNeto = descuentoNeto;
        this.no_pedido = no_pedido;
    }

    public int getId_detalle() {
        return id_detalle;
    }

    public void setId_detalle(int id_detalle) {
        this.id_detalle = id_detalle;
    }

    public int getNo_item() {
        return no_item;
    }

    public void setNo_item(int no_item) {
        this.no_item = no_item;
    }

    public int getCantidadArticulos() {
        return cantidadArticulos;
    }

    public void setCantidadArticulos(int cantidadArticulos) {
        this.cantidadArticulos = cantidadArticulos;
    }

    public String getCodigo_regalo() {
        return codigo_regalo;
    }

    public void setCodigo_regalo(String codigo_regalo) {
        this.codigo_regalo = codigo_regalo;
    }

    public int getId_envio() {
        return id_envio;
    }

    public void setId_envio(int id_envio) {
        this.id_envio = id_envio;
    }

    public float getPrecioNeto() {
        return precioNeto;
    }

    public void setPrecioNeto(float precioNeto) {
        this.precioNeto = precioNeto;
    }

    public float getDescuentoNeto() {
        return descuentoNeto;
    }

    public void setDescuentoNeto(float descuentoNeto) {
        this.descuentoNeto = descuentoNeto;
    }

    public String getNo_pedido() {
        return no_pedido;
    }

    public void setNo_pedido(String no_pedido) {
        this.no_pedido = no_pedido;
    }

    @Override
    public String toString() {
        return "Detalle{" + "id_detalle=" + id_detalle + ", no_item=" + no_item + ", cantidadArticulos=" + cantidadArticulos + ", codigo_regalo=" + codigo_regalo + ", id_envio=" + id_envio + ", precioNeto=" + precioNeto + ", descuentoNeto=" + descuentoNeto + ", no_pedido=" + no_pedido + '}';
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author user
 */
public class Cajero implements administrar <Producto>{
    
    String ci_cajero ;
    String nombres  ;
    String primerApellido  ;
    String segundoApellido ;
    String fecha_nacimiento;	
    String email;	   	    
    String genero  ;			
    String estadoCivil;		
    String direccionResidencia;   
    String sectorResidencia ;  
    int edad	;	
    String telefonoMovil1;	   
    String telefonoMovil2  ;  
    String telefonofijo   ; 	
    String nacionalidad;	
    String tipoEmpleado;	

    public String getCi_cajero() {
        return ci_cajero;
    }

    public void setCi_cajero(String ci_cajero) {
        this.ci_cajero = ci_cajero;
    }
    
    public Cajero(String ci_cajero, String nombres, String primerApellido, String segundoApellido, String fecha_nacimiento, String email, String genero, String estadoCivil, String direccionResidencia, String sectorResidencia, int edad, String telefonoMovil1, String telefonoMovil2, String telefonofijo, String nacionalidad, String tipoEmpleado) {
        this.ci_cajero = ci_cajero;
        this.nombres = nombres;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.fecha_nacimiento = fecha_nacimiento;
        this.email = email;
        this.genero = genero;
        this.estadoCivil = estadoCivil;
        this.direccionResidencia = direccionResidencia;
        this.sectorResidencia = sectorResidencia;
        this.edad = edad;
        this.telefonoMovil1 = telefonoMovil1;
        this.telefonoMovil2 = telefonoMovil2;
        this.telefonofijo = telefonofijo;
        this.nacionalidad = nacionalidad;
        this.tipoEmpleado = tipoEmpleado;
    }



    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getDireccionResidencia() {
        return direccionResidencia;
    }

    public void setDireccionResidencia(String direccionResidencia) {
        this.direccionResidencia = direccionResidencia;
    }

    public String getSectorResidencia() {
        return sectorResidencia;
    }

    public void setSectorResidencia(String sectorResidencia) {
        this.sectorResidencia = sectorResidencia;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getTelefonoMovil1() {
        return telefonoMovil1;
    }

    public void setTelefonoMovil1(String telefonoMovil1) {
        this.telefonoMovil1 = telefonoMovil1;
    }

    public String getTelefonoMovil2() {
        return telefonoMovil2;
    }

    public void setTelefonoMovil2(String telefonoMovil2) {
        this.telefonoMovil2 = telefonoMovil2;
    }

    public String getTelefonofijo() {
        return telefonofijo;
    }

    public void setTelefonofijo(String telefonofijo) {
        this.telefonofijo = telefonofijo;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getTipoEmpleado() {
        return tipoEmpleado;
    }

    public void setTipoEmpleado(String tipoEmpleado) {
        this.tipoEmpleado = tipoEmpleado;
    }
    
    @Override
    public String toString() {
        return "Cajero{" + "ci_cajero=" + ci_cajero + ", nombres=" + nombres + ", primerApellido=" + primerApellido + ", segundoApellido=" + segundoApellido + ", fecha_nacimiento=" + fecha_nacimiento + ", email=" + email + ", genero=" + genero + ", estadoCivil=" + estadoCivil + ", direccionResidencia=" + direccionResidencia + ", sectorResidencia=" + sectorResidencia + ", edad=" + edad + ", telefonoMovil1=" + telefonoMovil1 + ", telefonoMovil2=" + telefonoMovil2 + ", telefonofijo=" + telefonofijo + ", nacionalidad=" + nacionalidad + ", tipoEmpleado=" + tipoEmpleado + '}';
    }

    @Override
    public void agregar(Producto p) {
        //En construccion
    }

    @Override
    public void eliminar(Producto p) {
        //En construccion
    }

    @Override
    public void modificar(Producto p) {
       //En construccion
    }

    @Override
    public void consultar(Producto p) {
        //En construccion
    }
     

}

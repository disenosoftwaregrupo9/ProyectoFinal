/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Nicole
 */
public interface administrar <T>{
    public void agregar(T p);
    public void eliminar(T p);
    public void modificar(T p);
    public void consultar(T p);
    
}
